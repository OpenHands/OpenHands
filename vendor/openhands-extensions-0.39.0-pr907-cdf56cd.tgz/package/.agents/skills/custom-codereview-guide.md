---
name: custom-codereview-guide
description: Repository-specific review guidance for OpenHands/extensions.
triggers:
- /codereview
---

# OpenHands/extensions review guide

Apply this guide with the general code-review skill and `AGENTS.md`. Approve the
current head when it has no material correctness, security, compatibility, or
acceptance-criterion defect. Comment only on concrete failures; do not withhold
approval for optional refactors, tone, style, or speculative improvements.

## Repository scope

This repository owns reusable extensions: skills, plugins, and automation
bundles that use existing public host and runtime interfaces. Out of scope here,
because another repository owns the contract or machinery:

- SDK, agent-server, and client contracts — `OpenHands/software-agent-sdk`;
- generic automation scheduling, state, dispatch, and profile machinery —
  `OpenHands/automation`;
- Canvas product and UI integration — `OpenHands/OpenHands`.

Cross-repository work is acceptable when this PR contains only the
extensions-owned portion and relies on public interfaces from the owning
repository.

## Issue triage

Issue readiness means the work is clear enough to start—not that the fix is
complete. Do not require a PR, passing implementation tests, or before-and-after
fix evidence. Reconsider readiness when new information leaves scope or expected
behavior unresolved. Read the issue, linked discussion, applicable `AGENTS.md`,
and adjacent source before asking questions.

For API failures, compare the extension request with the provider's reported or
supported version, not upstream main. Use dependency pins or deployment evidence.
Instructions, request arguments, response parsing, and scanner policy belong
here; use the ownership boundaries above for other failures. State required
cross-repository changes and their order. An independent upstream defect need
not block this work. Naming an owner does not authorize edits or duplicate tickets.

Define the smallest useful outcome and explicit non-goals. Cover only affected
entrypoints, environments, and permissions. For scanners, state whether discovery,
commenting, and dispatch are allowed for ineligible candidates or after a cap.
Discovery alone does not authorize unsolicited comments.

Request visual evidence only when needed; otherwise use logs, minimal
reproductions, or failing tests. Do not repeat answered questions. Match managed
criteria to current human decisions and authoritative readiness policy. Report
conflicts instead of repeatedly adding a label that policy removes.

## Implementation review checkpoints

### Executable instructions and runtime parity

Commands, imports, environment variables, endpoints, and setup steps in extension
content are executable contracts. Verify them against the released packages and
the actual local and cloud environments that claim support. Do not approve an
example that relies on an unreleased API, a developer-only dependency, a private
path, or a variable that the production runtime does not provide.

For a changed skill, plugin, hook, or automation, follow its documented entrypoint
in a clean environment far enough to exercise the changed behavior. Keep local
and cloud behavior identical unless the documentation names and explains a real
platform capability difference.

For provider changes, inspect the supported implementation; mocks and local types
alone do not establish an API contract. Separate static/helper tests, tests with
simulated services, and real integration evidence. If the version or runtime is
unavailable, report that limit, not an assumed defect. For packaging changes,
check source, shipped bundle, and deployed files separately.

For scanners, check eligibility, permissions, caps, retries, unchanged runs, and
recovery for each action listed under triage. A launch cap does not permit
unlimited gate comments.

### Untrusted triggers and credentials

Treat repository events, issue and PR comments, chat messages, catalog fields,
and extension-provided arguments as untrusted. Verify who may trigger the action,
whose identity it runs as, which repository or organization it can affect, and
which secrets it receives. A trigger phrase alone is not authorization. Require
an explicit allowlist, permission check, or repository policy before performing
mutating or credentialed work.

Use only the minimum documented credential set. Never place secret values in
prompts, logs, generated files, examples, or persisted state.

### Sources of truth and generated artifacts

Identify the hand-authored source before reviewing a catalog or generated file.
A change should update that source once and regenerate every derived artifact
with the repository's existing sync/build command. Documentation must describe
the real direction of generation; do not call a generated asset the source of
truth or claim two runtimes read one asset when they do not.

Check the marketplace entry and generated command/catalog coverage required by
`AGENTS.md`. Do not add a parallel catalog, provider-specific copy, or manual
compatibility layer when the repository already has a generator or schema.

### Documentation claims

Test copy-paste commands and verify named tools, flags, package exports, URLs, and
installation mechanisms from authoritative sources. A plausible command is not
evidence. Documentation that teaches the wrong data flow or setup is a material
finding because agents execute it directly.

SDK documentation belongs in `docs.openhands.dev/sdk`; the generated
`skills/openhands-sdk/SKILL.md` remains a thin synchronized entrypoint. The
former `@openhands/extensions/mcps` catalog was experimental and pre-release, so
an explicitly coordinated replacement with the `integrations` catalog needs
consumer migration documentation but not compatibility aliases or a deprecation
window.

### Dependencies and supply chain

Validate installation with the package manager and runtime used by the extension.
Temporary git pins and unreleased package APIs are blockers for merge unless the
PR is an explicit, coordinated stack that will replace them before release.

For dependency additions or updates, inspect every changed third-party npm or
PyPI version, including transitive lockfile changes. Require at least seven days
since publication of that exact version. Use registry publication/upload metadata
or the relevant artifact's `uv.lock` `upload-time`; a weekly bot schedule, an old
package name, or a passing install is not age evidence.

For an under-seven-day artifact, leave a COMMENT naming the package, version,
publication time, and source, and defer approval until it ages out or a maintainer
explicitly approves a narrowly documented exception. If publication time is
unavailable, ask for that evidence. Existing named first-party exemptions apply
only to those packages, not their third-party dependencies or blanket approval
of the lockfile. Apply this check before any dependency-bump fast path.

Flag removal or weakening of seven-day uv/Dependabot guards or new broad
exemptions. Dependabot security updates bypass cooldown, so review them under
the explicit maintainer-exception rule in `AGENTS.md`; agents cannot approve
their own bypass.

### Design context for deep changes

A diff shows edits, not always the design. Expect concise design context when a
reviewer cannot judge a change from the diff in a few minutes: a new or changed
skill, plugin, automation, integration contract, or manifest schema; a new
subsystem, migration, or cross-cutting refactor; a behavior change in shared
loading, validation, discovery, or execution; or a large diff whose intent is
hard to hold once generated files, lockfiles, snapshots, vendored code, and
mechanical churn are set aside. Typos, one-line guards, dependency bumps, small
documentation edits, and localized fixes need none. Line count is a signal,
never a gate by itself.

Design context is an available design-doc artifact or a durable write-up in the
PR description that states the intent, the important before/after behavior or
contract shape, compatibility and risk, and grounded code references. When a
deep change lacks it, weigh the gap by risk:

- **HIGH** risk: do not approve; submit a COMMENT review that asks for design
  context before a human merge decision.
- **MEDIUM** risk: withhold approval only when reconstructing the design from
  the diff would materially slow or weaken the review.
- **LOW** risk: never block on missing design context alone.

Temporary `.pr/` artifacts remain available during review and are removed through
a cleanup PR after merge to `main`. Preserve any design explanation needed beyond
that cleanup in the PR description or permanent documentation.

Design context aids review; it does not excuse correctness, security,
architecture, or repository-ownership problems.

## Evidence and comment discipline

Evidence should exercise the extension as users invoke it: run the command, hook,
plugin, or automation entrypoint and show the relevant result. Static text checks
alone do not validate executable instructions. Require only the environments and
paths the change affects.

Do not comment on punctuation, preferred prose tone, optional DRY cleanup, or
hypothetical non-standard configurations without a supported failure mode. Before
raising a finding, verify that the referenced file and behavior are present in
the current PR head and have not already been addressed in review history.

## Review verdict

Do not approve material code defects or unmet blocking merge/evidence checks.
Distinguish code defects from missing merge requirements and optional follow-up.
If GitHub forbids self-approval of a clean PR, use COMMENT and explain why.
Respect accepted scope and non-goals: block on a pre-existing limitation only if
this change exposes it.
